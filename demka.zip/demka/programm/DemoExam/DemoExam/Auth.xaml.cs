﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        public Auth()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Авторизация и получение собыитя кнопки входа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnterLogin(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(login.Text))
            {
                if (!String.IsNullOrWhiteSpace(password.Password))
                {
                    var user = dataEntities.GetContext().Users.Where(p => p.login == login.Text).Where(p => p.password == password.Password).FirstOrDefault(); // получение данных по логину и паролю

                    if (user != null)
                    {
                        UserData.user_id = user.user_ID;
                        switch (user.role)
                        {
                            case "Студент":
                                MessageBox.Show("Вы авторизованы как студент.");
                                Manager.MainFrame.Navigate(new StudentPage());
                                break;
                            case "Преподаватель":
                                MessageBox.Show("Вы авторизованы как преподаватель.");
                                break;
                            case "Администратор":
                                MessageBox.Show("Вы авторизованы как администратор.");
                                Manager.MainFrame.Navigate(new AdminPage());
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль. Пожалуйста, проверьте еще раз данные.");
                        password.Password = "";
                    }
                }
                else
                {
                    MessageBox.Show("Поле пароль не может быть пустым");
                }
            }
            else
            {
                MessageBox.Show("Поле логин не может быть пустым");
            }
        }
    }
}
