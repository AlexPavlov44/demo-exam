﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DemoExam
{
    /// <summary>
    /// Класс переключения страниц
    /// </summary>
    class Manager
    {
        /// <summary>
        /// Хранение данных о фрейме
        /// </summary>
        public static Frame MainFrame { get; set; }
    }
}
