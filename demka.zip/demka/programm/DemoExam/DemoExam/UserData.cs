﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoExam
{
    /// <summary>
    /// Хранение данных о пользователе
    /// </summary>
    static class UserData
    {
        /// <summary>
        /// id пользователя
        /// </summary>
        public static int user_id { get; set; }
    }
}
