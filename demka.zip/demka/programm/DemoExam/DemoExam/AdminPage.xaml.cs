﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Page
    {
        public AdminPage()
        {
            InitializeComponent();
            loadData();
        }

        /// <summary>
        /// Загрузка данных
        /// </summary>
        private void loadData()
        {
            List<DataOfAdmin> dataAdmin = new List<DataOfAdmin>();

            var disciplines = dataEntities.GetContext().Subjects.ToList();

            foreach (var disciplina in disciplines)
            {
                foreach (var group in disciplina.Groups)
                {
                    foreach (var teacher in disciplina.Teachers)
                    {
                        dataAdmin.Add(new DataOfAdmin() { disciplina = disciplina.title, group = group.title, teacher = teacher.secondname + " " + teacher.firstname + " " + teacher.thirdname });
                    }
                }
            }

            DataOfUsers.ItemsSource = dataAdmin;
        }

        /// <summary>
        /// Переход на страницу преподаватлей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TeachersAdminPage(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TeachersList());
        }

        /// <summary>
        /// Переход на страницу групп
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GroupsAdminPage(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new GroupsList());
        }

        /// <summary>
        /// Переход на страницу Студентов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StudentsAdminPage(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new StudentsList());
        }
    }

    /// <summary>
    /// Класс для хранения данных о студентах
    /// </summary>
    class DataOfAdmin
    {
        public string disciplina { get; set; }
        public string group { get; set; }
        public string teacher { get; set; }
    }
}
