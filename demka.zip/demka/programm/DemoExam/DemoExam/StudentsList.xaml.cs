﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для StudentsList.xaml
    /// </summary>
    public partial class StudentsList : Page
    {
        public StudentsList()
        {
            InitializeComponent();
            loadData();
        }

        /// <summary>
        /// Кнопка перехода на прошлое окно
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Back(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        /// <summary>
        /// Загрузка данных
        /// </summary>
        private void loadData()
        {
            var data = dataEntities.GetContext().Students.ToList();
            DataOfUsers.ItemsSource = data;
        }

        private void Add(object sender, RoutedEventArgs e)
        {

        }
    }
}
