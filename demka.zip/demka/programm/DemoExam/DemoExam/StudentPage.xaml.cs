﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для StudentPage.xaml
    /// </summary>
    public partial class StudentPage : Page
    {
        public StudentPage()
        {
            InitializeComponent();
            loadData();
        }

        /// <summary>
        /// Выйти из аккаунта, собыите кнопки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Logout(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Auth());
        }

        /// <summary>
        /// Прогрузка данных при загрузке страницы
        /// </summary>
        private void loadData()
        {
            var data = dataEntities.GetContext().Students.Where(p => p.student_ID == UserData.user_id).FirstOrDefault();

            FIO.Text = data.secondname + " " + data.firstname + " " + data.thirdname;
            group.Text = data.Groups.title;
            spec.Text = data.Groups.specialnost;

            var disciplines = dataEntities.GetContext().Groups.Where(p => p.group_ID == data.group_ID).FirstOrDefault().Subjects.ToList();

            disciplina.ItemsSource = disciplines;
        }

        /// <summary>
        /// Получение данных
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GetData(object sender, RoutedEventArgs e)
        {
            if (disciplina.Items != null)
            {
                Manager.MainFrame.Navigate(new AttestationView(disciplina.SelectedItem as Subjects));
            }            
        }
    }
}
