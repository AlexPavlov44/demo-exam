﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для AttestationView.xaml
    /// </summary>
    public partial class AttestationView : Page
    {
        public AttestationView(Subjects _subject)
        {
            InitializeComponent();
            loadData(_subject);
        }

        /// <summary>
        /// Вернуться на предыдующую страницу
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Back(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        /// <summary>
        /// Выйти из аккаунта, собыите кнопки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Logout(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Auth());
        }

        /// <summary>
        /// Загрузка данных
        /// </summary>
        private void loadData(Subjects subject)
        {
            var test = subject;
            var attestation = dataEntities.GetContext().AttestationStudent.Where(p => p.student_id == UserData.user_id).Where(s => s.subject_id == subject.subject_ID).ToList();

            foreach (var item in attestation)
            {
                item.teacher = item.Teachers.FirstOrDefault();
            }

            DataOfAttestation.ItemsSource = attestation;
        }
    }
}
